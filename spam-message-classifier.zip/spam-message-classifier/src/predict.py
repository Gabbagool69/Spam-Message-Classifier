# src/predict.py

def classify_message(model, vectorizer, message):
    """
    Classify a single message as spam (1) or not spam (0).
    """
    X = vectorizer.transform([message])
    prediction = model.predict(X)[0]
    return prediction
