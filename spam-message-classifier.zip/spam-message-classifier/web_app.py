# web_app.py

from flask import Flask, request, render_template, jsonify
import joblib
from src.data_loader import load_data
from src.predict import classify_message
from src.lime_explainer import explain_with_lime

app = Flask(__name__)

# Load vectorizer
_, _, _, _, vectorizer = load_data()

# Load trained model
model = joblib.load("models/nb_model.pkl")

@app.route('/', methods=['GET', 'POST'])
def index():
    result = ""
    explanation = []

    if request.method == 'POST':
        message = request.form['message']
        prediction = classify_message(model, vectorizer, message)
        result = "🚫 Spam" if prediction == 1 else "✅ Not Spam"

        # Run LIME and get top words
        explanation = explain_with_lime(model, vectorizer, message)

    return render_template('index.html', result=result, explanation=explanation)

@app.route('/api/predict', methods=['POST'])
def predict_api():
    data = request.get_json()
    message = data.get("message", "")
    prediction = classify_message(model, vectorizer, message)
    return jsonify({
        "message": message,
        "prediction": "spam" if prediction == 1 else "not spam"
    })

if __name__ == '__main__':
    app.run(debug=True)

