# src/explain_model.py

import shap
import numpy as np

def explain_with_shap(model, vectorizer, message):
    """
    Use SHAP to explain why a message is classified as spam or not.
    """
    # Convert message into the same feature format
    X_message = vectorizer.transform([message])

    # SHAP requires dense array
    X_dense = X_message.toarray()

    # Create SHAP explainer for linear model
    explainer = shap.Explainer(model.predict_proba, vectorizer.transform)

    # Explain the instance
    shap_values = explainer([message])

    # Plot explanation
    print("\nSHAP Explanation:")
    shap.plots.text(shap_values[0])
