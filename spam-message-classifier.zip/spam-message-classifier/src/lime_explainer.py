# src/lime_explainer.py

from lime.lime_text import LimeTextExplainer

def explain_with_lime(model, vectorizer, message):
    class_names = ["Not Spam", "Spam"]

    def predict_proba(texts):
        X = vectorizer.transform(texts)
        return model.predict_proba(X)

    explainer = LimeTextExplainer(class_names=class_names)

    explanation = explainer.explain_instance(
        message,
        predict_proba,
        num_features=6,
        labels=[0, 1]
    )

    # Return explanation as a list of (word, score) tuples
    return explanation.as_list()

