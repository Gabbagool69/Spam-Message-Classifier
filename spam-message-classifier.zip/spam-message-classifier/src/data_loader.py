# src/data_loader.py

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split

def load_data(csv_path='data/raw/spam.csv'):
    # Load the CSV file (only the useful columns)
    df = pd.read_csv(csv_path, encoding='latin-1', usecols=['v1', 'v2'])

    # Rename for easier reference
    df = df.rename(columns={'v1': 'label', 'v2': 'message'})

    # Convert text labels to numeric: ham → 0, spam → 1
    df['label'] = df['label'].map({'ham': 0, 'spam': 1})

    # Drop any NaNs just in case
    df = df.dropna()

    # Vectorize text using TF-IDF
    vectorizer = TfidfVectorizer(stop_words='english')
    X = vectorizer.fit_transform(df['message'])
    y = df['label']

    # Split the dataset into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Return the full set plus vectorizer
    return X_train, X_test, y_train, y_test, vectorizer







