# main.py

from src.lime_explainer import explain_with_lime
from src.data_loader import load_data
from src.explain_model import explain_with_shap
from src.train_model import train_naive_bayes, evaluate_model
from src.predict import classify_message

def main():
    # Load and preprocess data
    X_train, X_test, y_train, y_test, vectorizer = load_data()

    # Train the Naive Bayes model
    model = train_naive_bayes(X_train, y_train)

    # Evaluate model performance
    evaluate_model(model, X_test, y_test)

    # Prompt user for input
    message = input("\n📩 Enter a message to classify: ")

    # Predict if it's spam
    prediction = classify_message(model, vectorizer, message)
    print("\nPrediction:", "🚫 Spam" if prediction == 1 else "✅ Not Spam")

    # Explain with SHAP + LIME
    explain_with_shap(model, vectorizer, message)
    explain_with_lime(model, vectorizer, message)

if __name__ == '__main__':
    main()

